class Shop:
    gold = [
        {
            'Cost': 20,
            'Amount': 150
        },

        {
            'Cost': 50,
            'Amount': 400
        },

        {
            'Cost': 140,
            'Amount': 1200
        },

        {
            'Cost': 280,
            'Amount': 2600
        },

    ]

    boxes = [
        {
            'Name': 'Big Box',
            'Cost': 30,
            'Multiplier': 3
        },

        {
            'Name': 'Mega Box',
            'Cost': 80,
            'Multiplier': 10
        }

    ]


    token_doubler = {

        'Cost': 50,
        'Amount': 1000
    }
    
    offers = [
        {
         "OfferID": 10,
         "DataReference": [16,0],
         "Skin": 0,
         "ShopType": 0,
         "ShopDisplay": 0,
         "Cost": 19,
         "OldCost": 80,
         "Timer": 172799,
         "Multiplier": 1,
         "OfferText": "ОСОБАЯ АКЦИЯ",
         "Claimed": False,
         "OfferBG": 'offer_chromatic',
         "Appearance": 0,
         "ETType": 0,
         "ETMultiplier": 0
      },

        {
         "OfferID": 16,
         "DataReference": [16,0],
         "Skin": 0,
         "ShopType": -1,
         "ShopDisplay": 0,
         "Cost": 0,
         "OldCost": 0,
         "Timer": 172799,
         "Multiplier": 80,
         "OfferText": "ОТКРЫТИЕ НЗВАНИЕ ВАШЕГО СЕРВЕРА!",
         "Claimed": False,
         "OfferBG": 'offer_finals',
         "Appearance": 0,
         "ETType":0,
         "ETMultiplier": 0
      },
      
    ]



