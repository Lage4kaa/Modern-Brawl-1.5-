from ByteStream.Reader import Reader
from Protocol.Messages.Server.Home.LeaderboardMessage import LeaderboardMessage


class GetLeaderboardMessage(Reader):
    def __init__(self, client, player, header_bytes):
        super().__init__(header_bytes)
        self.client = client
        self.player = player

    def decode(self):
        self.playerID = self.readLong()

    def process(self):
        LeaderboardMessage(self.client, self.player, self).send()