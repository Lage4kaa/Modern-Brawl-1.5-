from Utils.Writer import Writer


class BattleLogMessage(Writer):
    def __init__(self, client, player, entry):
        super().__init__(client)
        self.id = 23458
        self.client = client
        self.player = player
        self.info = entry

    def encode(self):
        self.writeBoolean(True)
        
        self.writeVint(1) # Count
        
        self.writeVint(0)
        self.writeVint(0)    # Time When Battle Log Entry Was Created
        self.writeVint(1)    # Battle Log Type (1 = Normal, 2 = Crash, 3 = Survived for <time>, 
        self.writeVint(-6)    # Trophies Result
        self.writeVint(125)  # Battle Time
        self.writeUInt8(1)   # Type [0 = Power Play, 1 = Friendly, 2 = Championship]
        self.writeScId(15, 7) # Map SCID
        self.writeVint(1) # Victory/Defeat/Draw
        self.writeVint(999) # ???

        self.writeInt(0)
        self.writeInt(0)

        self.writeVint(1)
        self.writeUInt8(1)

        self.writeInt(0) #unk
        
        self.writeScId(16, 34)
        self.writeScId(29, 0)
        self.writeByte(0)
        self.writeString("JACKY")
        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)

        self.writeInt(0) #High ID
        self.writeInt(2) #Low ID
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)