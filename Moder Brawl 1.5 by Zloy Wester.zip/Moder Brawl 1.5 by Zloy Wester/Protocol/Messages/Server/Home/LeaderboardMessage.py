from ByteStream.Writer import Writer


class LeaderboardMessage(Writer):
    def __init__(self, client, player, entry):
        super().__init__(client)
        self.id = 24403
        self.client = client
        self.player = player
        self.info = entry

    def encode(self):
        self.writeVInt(1) # Leaderboard Variation
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()

        self.writeVInt(2) # Players Count
        
        # Player Data #
        self.writeVInt(0)
        self.writeVInt(1)
        
        self.writeVInt(1)
        self.writeVInt(self.player.trophies) #trophies
        
        self.writeVInt(1)
        self.writeString("t.me/grom_studio") # Club Name
        
        self.writeString("Тут могла быть ваша реклама") # Player Name
        self.writeVInt(0)
        self.writeVInt(28000079) # Player Thumbnail
        self.writeVInt(43000005) # Name Color
        self.writeVInt(46000005) # Name Gradient
        self.writeVInt(0) #UNK
        # Player Data #
        
        # Player Data #
        self.writeVInt(0)
        self.writeVInt(1)
        
        self.writeVInt(1)
        self.writeVInt(30000) #trophies
        
        self.writeVInt(1)
        self.writeString("t.me/grom_studio") # Club Name
        
        self.writeString("Zloy Wester<3") # Player Name
        self.writeVInt(0)
        self.writeVInt(28000078) # Player Thumbnail
        self.writeVInt(43000003) # Name Color
        self.writeVInt(-1) # Name Gradient
        self.writeVInt(0) #UNK
        # Player Data #

        self.writeVInt(99)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("RU")