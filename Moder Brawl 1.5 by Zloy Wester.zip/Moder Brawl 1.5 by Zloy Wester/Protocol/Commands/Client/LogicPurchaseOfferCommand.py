from ByteStream.Reader import Reader
from Logic.Shop import Shop
from Protocol.Messages.Server.AvailableServerCommandMessage import AvailableServerCommandMessage

class LogicPurchaseOfferCommand(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.readVInt()
        self.readVInt()
        self.readLogicLong()

        self.offer_index = self.readVInt()

        self.brawler = self.readDataReference()[1]

    def process(self, db):
        offer_id       = LogicShopData.offers[self.offer_index]['OfferID']
        offer_resource = LogicShopData.offers[self.offer_index]['ShopType']
        offer_cost     = LogicShopData.offers[self.offer_index]['Cost']
        offer_amount   = LogicShopData.offers[self.offer_index]['Multiplier']
        offer_char = LogicShopData.offers[self.offer_index]['DataReference'][1]